<?php
class Dan_SCA_Block_Adminhtml_State_Info_Edit_Form extends Mage_Adminhtml_Block_Widget_Form {

    protected function _prepareForm(){
        // Instantiate a new form to display our state for editing.
        $form = new Varien_Data_Form(array(
            'id' => 'edit_form',
            'action' => $this->getUrl('dan_sca_admin/state_info/edit', array(
				'_current' => true,
				'continue' => 0,
			)),
            'method' => 'post',
		));
        $form->setUseContainer(true);
        $this->setForm($form);

        // define a new fieldset. We need only one for our simple entity.
        $fieldset = $form->addFieldset(
            'general', array(
				'legend' => $this->__('Details on info required by the State')
			)
        );

        $stateSingleton = Mage::getSingleton('dan_sca/state_info');

        // add the fields that we want to be editable.
        $this->_addFieldsToFieldset($fieldset, array(
            'name' => array(
                'label' => $this->__('Name'),
                'input' => 'text',
                'required' => true,
            ),
            'attribute_code' => array(
                'label' => $this->__('Attribute Code'),
                'input' => 'text',
                'required' => true,
            ),
            'input_type' => array(
                'label' => $this->__('Input Type'),
				'input' => 'select',
				'options' => array(
					'text'	=> 'Text', 
					'date'	=> 'Date'
					),
                'required' => true,
			),
            'is_required' => array(
                'label' => $this->__('Required?'),
				'input' => 'select',
				'options' => array (
						1 => 'Yes',
						0 => 'No'
        			),
                'required' => true,
			),
            'parent_id' => array(
                'label' => $this->__('Parent ID'),
                'input' => 'hidden',
                'required' => true,
			)
        ));

        return $this;
    }

    protected function _addFieldsToFieldset(Varien_Data_Form_Element_Fieldset $fieldset, $fields){
        $requestData = new Varien_Object($this->getRequest()->getPost('state_infoData'));
		
		// set the parent_id from current_state for new objects ==> will return false if we are editing
		$parent_id = $this->_getHelper()->getState()->getId();

        foreach ($fields as $name => $_data) {
            if ($requestValue = $requestData->getData($name)) {
                $_data['value'] = $requestValue;
            }

            // Wrap all fields with state_infoData group.
            $_data['name'] = "state_infoData[$name]";
            $_data['title'] = $_data['label'];
			
            // if no new value exists, use the existing state_info data.
            if(!array_key_exists('value', $_data))
                $_data['value'] = $this->_getStateInfo()->getData($name);
			
			// since parent_id will only set for new objects, we can use it as a proxy for new/edit mode ...
			if($parent_id){
				if($name == 'parent_id')
					$_data['value'] = $parent_id;
			}
			else{
				// ... thus, we prevent the user from editing the attribute_code or input_type values
				if($name == 'attribute_code' || $name == 'input_type'){
					$_data['disabled'] = 'disabled';
					$afterElementHtml = '<span class="nm" style="color:red;"><small>disabled</small></span>';
					$_data['after_element_html'] = $afterElementHtml;
				};
			};
			
            // finally, call vanilla functionality to add field.
            $fieldset->addField($name, $_data['input'], $_data);
        };
		
        return $this;
    }

    protected function _getStateInfo(){
        if (!$this->hasData('stateInfo')) {
            // This will have been set in the controller.
            $info = Mage::registry('current_stateInfo');

            // Just in case the controller does not register the piece of info.
            if (!$info instanceof Dan_SCA_Model_State_Info) {
                $info = Mage::getModel('dan_sca/state_info');
            }

            $this->setData('stateInfo', $info);
        }

        return $this->getData('stateInfo');
    }
	
    protected function _getHelper(){
        return Mage::helper('dan_sca');
    }
}
?>