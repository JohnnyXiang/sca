<?php
class Dan_SCA_Block_Adminhtml_State_Info_Edit extends Mage_Adminhtml_Block_Widget_Form_Container {
    protected function _construct(){
        $this->_blockGroup = 'dan_sca_adminhtml';
        $this->_controller = 'state_info';
        $this->_mode = 'edit';

        $newOrEdit = $this->getRequest()->getParam('id') ? $this->__('Edit') : $this->__('New');
        $this->_headerText =  $newOrEdit . ' ' . $this->__('Required Info');
    }
}
?>