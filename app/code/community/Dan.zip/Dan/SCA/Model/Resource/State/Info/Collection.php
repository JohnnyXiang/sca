<?php
class Dan_SCA_Model_Resource_State_Info_Collection extends Mage_Core_Model_Resource_Db_Collection_Abstract {
    protected function _construct(){
        parent::_construct();
        $this->_init(
            'dan_sca/state_info',
            'dan_sca/state_info'
        );
    }
}
?>