## Sportsmans Common App

Install Notes:

1. Install "Groups Catalog" extension (http://www.magentocommerce.com/magento-connect/customer-groups-catalog2.html) in order to hide Membership from GROUP == Members ... just for cleanliness
2. Edited 'Add to Cart' of RWD tempate directly in order to (by default) show  